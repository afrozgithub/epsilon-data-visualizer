package coffee;

interface Heater {
  void on();
  void off();
  boolean isHot();
}
