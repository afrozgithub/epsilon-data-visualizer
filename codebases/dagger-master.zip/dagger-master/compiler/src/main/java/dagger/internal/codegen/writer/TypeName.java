package dagger.internal.codegen.writer;

public interface TypeName extends HasClassReferences, Writable {
}
