package dagger.internal.codegen.writer;

interface HasTypeName {
  TypeName name();
}
