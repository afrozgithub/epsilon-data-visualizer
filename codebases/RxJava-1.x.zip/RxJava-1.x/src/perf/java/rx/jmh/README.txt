For examples see:

http://hg.openjdk.java.net/code-tools/jmh/file/tip/jmh-samples/src/main/java/org/openjdk/jmh/samples/
https://github.com/nitsanw/jmh-samples/blob/master/src/main/java/org/openjdk/jmh/samples/
https://github.com/nitsanw/jmh-samples/blob/master/src/main/java/org/openjdk/jmh/samples/JMHSample_15_Asymmetric.java
https://github.com/nitsanw/jmh-samples/blob/master/src/main/java/org/openjdk/jmh/samples/JMHSample_09_Blackholes.java#L86
