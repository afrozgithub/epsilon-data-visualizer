package jdepend.framework.p3;

public enum ExampleSecondEnum {
	NO_DEPENDENCIES_ON_ME
}
